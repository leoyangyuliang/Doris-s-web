#/bin/sh
nodejs server.js
node server.js

