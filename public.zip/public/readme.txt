

things need to be add


·in draw()
  pointLight, ambientMaterial, background draw sun and moon.
  时钟


·
